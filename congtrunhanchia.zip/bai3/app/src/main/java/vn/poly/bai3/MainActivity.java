package vn.poly.bai3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText edtNum1;
    private EditText edtNum2;
    public void cong(View view){
        Intent int1= new Intent(MainActivity.this,ketquaActivity.class);
        double num1=Integer.parseInt(edtNum1.getText().toString());
        double num2=Integer.parseInt(edtNum2.getText().toString());
        double sum= num1+num2;
        int1.putExtra("kq",sum);
        startActivity(int1);
    }
    public void tru(View view){
        Intent int1= new Intent(MainActivity.this,ketquaActivity.class);
        double num1=Integer.parseInt(edtNum1.getText().toString());
        double num2=Integer.parseInt(edtNum2.getText().toString());
        double sum= num1-num2;
        int1.putExtra("kq",sum);
        startActivity(int1);
    }
    public void nhan(View view){
        Intent int1= new Intent(MainActivity.this,ketquaActivity.class);
        double num1=Integer.parseInt(edtNum1.getText().toString());
        double num2=Integer.parseInt(edtNum2.getText().toString());
        double sum= num1*num2;
        int1.putExtra("kq",sum);
        startActivity(int1);
    }
    public void chia(View view){
        Intent int1= new Intent(MainActivity.this,ketquaActivity.class);
        double num1=Integer.parseInt(edtNum1.getText().toString());
        double num2=Integer.parseInt(edtNum2.getText().toString());
        double sum= num1/num2;
        int1.putExtra("kq",sum);
        startActivity(int1);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edtNum1=findViewById(R.id.edtNum1);
        edtNum2=findViewById(R.id.edtNum2);
    }
}
